#include <stdio.h>
#include <stdlib.h>

void printLabyrinth();
int makeMove(int index);
void makePlayerMove(char m);
//int improvedMakeMove(int index); //doesn't get out of bounds from left or right side. For example we could have trap exits that are not '@'.

int W = 21;
int H = 11;
int startX = 1;
char temp[100];
int playerPos = 1;
int TotalElements = 231;

char map[232] = "I.IIIIIIIIIIIIIIIIIII"                    
                "I....I....I.......I.I"                    
                "III.IIIII.I.I.III.I.I"                    
                "I.I.....I..I..I.....I"                    
                "I.I.III.II...II.I.III"                    
                "I...I...III.I...I...I"                    
                "IIIII.IIIII.III.III.I"                    
                "I.............I.I...I"                    
                "IIIIIIIIIIIIIII.I.III"                    
                "@...............I..II"                    
                "IIIIIIIIIIIIIIIIIIIII";

int main()
{
char mov;

while(map[playerPos] != '@') {
    printLabyrinth();
    printf("Make your move:");
    scanf("%s", &mov); //Scanned as string because otherwise user input "s\n" (for example) makes the program run twice.
                       //Once for mov='s' and once for mov='\n'. Now that we scan the whole input as a string, only the 
                       //first character of that input is being "transfered" to variable "mov" while the rest of the string
                       //is never being used since it has been scanned and therefore deleted from the system input file.
    if(mov=='e' || mov=='E') {
        makeMove(startX);
        printLabyrinth();
        printf("This Is The Fastest Path To The Exit!\n");
        break;
    }

    makePlayerMove(mov);
    
    if(map[playerPos]=='@') {
        printf("Winner Winner Chicken Dinner!\n");
    }
}

return 0;
}


void printLabyrinth() {
    int i, j, k = 0;
    usleep(200000);
    printf("\n");
    printf("Labyrinth:\n");
    for (i=0; i<H; i++) {
        for(j=0; j<W; j++) {
            if(k == playerPos)
                temp[j] = 'P';
            else
                temp[j] = map[k];
            k++;
        }
    temp[j+1] = '\0';
    printf("%s\n", temp);
    }
    printf("\n");
}

int makeMove(int index){
    if(index<0 || index>=TotalElements)
        return 0;
    
    if(map[index]=='.') {
        map[index]='*';
        printLabyrinth();
        
        //try moving right
        if(makeMove(index+1)==1){
            map[index]='#';
            return 1;
        }
        
        //try moving down
        if(makeMove(index+W)==1){
            map[index]='#';
            return 1;
        }
        
        //try moving left
        if(makeMove(index-1)==1){
            map[index]='#';
            return 1;
        }
        
        //try moving up
        if(makeMove(index-W)==1){
            map[index]='#';
            return 1;
        }
        
    }else if (map[index]=='@'){
        map[index]='%';
        printLabyrinth();
        return 1;
    }
    
    return 0;
}

void makePlayerMove(char m) {
    int i;
    int restrictedPos;
    
    if(m == 'd' || m == 'D') {//move right
        for(i=1; i<=H; i++) {
            restrictedPos = i * W;
            if((playerPos+1) == restrictedPos) {
                printf("Can't get out of bounds!\n");
                return;
            }
        }

        if(map[playerPos+1] == 'I') {
            printf("Can't move to a wall!\n");
            return;
        }

        playerPos = playerPos + 1;
        return;
    }
    
    if(m == 's' || m == 'S') {//move down
        if(playerPos+W >= TotalElements) {
            printf("Can't get out of bounds!\n");
            return;
        }

        if(map[playerPos+W] == 'I') {
            printf("Can't move to a wall!\n");
            return;
        }

        playerPos = playerPos + W;
        return;

    }
    
    if(m == 'a' || m == 'A') {//move left
        for(i=0; i<H; i++) {
            restrictedPos = (i*(W-1)) + (i-1); 
            if((playerPos-1) == restrictedPos) {
                printf("Can't get out of bounds!\n");
                return;
            }
        }

        if(map[playerPos-1] == 'I') {
            printf("Can't move to a wall!\n");
            return;
        }

        playerPos = playerPos - 1;
        return;
    }
    
    if(m == 'w' || m == 'W') {//move up
        if(playerPos-W < 0) {
            printf("Can't get out of bounds!\n");
            return;
        }

        if(map[playerPos-W] == 'I')  {
            printf("Can't move to a wall!\n");
            return;
        }

        playerPos = playerPos - W;
        return;
    }
    
    printf("Please use the keys \"W,A,S,D\" to play,\nor the key \"E\" to get the optimum solution...\n");
}

/*
int improvedMakeMove(int index) { //doesn't get out of bounds from left or right side
    int i, restrictedPos;
    int flagRight = 1; //used as boolean
    int flagLeft = 1; //used as boolean
    
    if(index<0 || index>=TotalElements)
        return 0;
    
    if(map[index]=='.') {
        map[index]='*';
        printLabyrinth();
        
        //try moving right
        for(i=1; i<=H; i++) {
            restrictedPos = i * W;
            if((index+1) == restrictedPos) {
                flagRight = 0;
            }
        }
        
        if(flagRight == 1) {//if by moving to the right we do not get out of bounds
            if(improvedMakeMove(index+1)==1) {
                map[index]='#';
                return 1;
            }
        }
        
        //try moving down
        if(improvedMakeMove(index+W)==1) {
            map[index]='#';
            return 1;
        }
    
        //try moving left
        for(i=0; i<H; i++) {
            restrictedPos = (i * (W - 1)) + (i-1); 
            if((index-1) == restrictedPos) {
                flagLeft = 0;
            }
        }
    
        if(flagLeft == 1) {//if by moving to the left we do not get out of bounds
            if(improvedMakeMove(index-1)==1) {
                map[index]='#';
                return 1;
            }    
        }
    
        //try moving up
        if(improvedMakeMove(index-W)==1) {
            map[index]='#';
            return 1;
        }
        
    }else if(map[index]=='@') {
        map[index]='%';
        printLabyrinth();
        return 1;
    }
    
    return 0;
} 
*/